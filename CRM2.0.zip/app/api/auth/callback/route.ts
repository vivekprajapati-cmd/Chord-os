import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');

  if (code) {
    const supabase = await createClient();
    await supabase.auth.exchangeCodeForSession(code);

    // Use service-role client to link auth.users → people row (bypasses RLS)
    const { data: { user } } = await supabase.auth.getUser();
    if (user?.email) {
      const admin = createAdminClient();
      await admin
        .from('people')
        .update({ auth_user_id: user.id })
        .eq('email', user.email)
        .is('auth_user_id', null);
    }
  }

  return NextResponse.redirect(`${origin}/dashboard`);
}
