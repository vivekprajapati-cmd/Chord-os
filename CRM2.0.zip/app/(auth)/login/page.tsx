'use client';

import { Suspense, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useSearchParams } from 'next/navigation';

function LoginForm() {
  const supabase = createClient();
  const [loading, setLoading] = useState(false);
  const params = useSearchParams();
  const error = params.get('error');

  async function signIn() {
    setLoading(true);
    const origin = window.location.origin;
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${origin}/api/auth/callback`,
      },
    });
  }

  return (
    <div className="w-full max-w-md bg-[var(--paper)] border border-[var(--line)] rounded-2xl p-10 shadow-[8px_8px_0_var(--ink)]">
      <h1 className="font-display text-5xl uppercase tracking-tight mb-2">ChordOS</h1>
      <p className="text-sm text-[var(--gray)] mb-8">
        Internal workspace. Sign in with your <strong>1702digital.com</strong> or <strong>ampmnetwork.com</strong> Google account.
      </p>
      {error === 'domain' && (
        <div className="mb-6 p-3 border rounded text-sm" style={{ background: 'rgba(255,59,47,0.08)', borderColor: 'var(--red)', color: 'var(--red)' }}>
          That email is not authorized. Use a 1702digital.com or ampmnetwork.com account.
        </div>
      )}
      <button
        onClick={signIn}
        disabled={loading}
        className="w-full uppercase tracking-[0.12em] text-sm font-mono py-4 rounded-full hover:opacity-90 disabled:opacity-50 transition"
        style={{ background: 'var(--ink)', color: 'var(--cream)' }}
      >
        {loading ? 'Redirecting…' : 'Sign in with Google'}
      </button>
      <p className="text-xs text-[var(--gray)] mt-6 font-mono">
        edernityteam.slack.com · 1702 Digital + Chord
      </p>
    </div>
  );
}

export default function LoginPage() {
  return (
    <main className="min-h-screen flex items-center justify-center px-6 bg-[var(--cream)]">
      <Suspense fallback={null}>
        <LoginForm />
      </Suspense>
    </main>
  );
}
