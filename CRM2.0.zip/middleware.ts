import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

const ALLOWED_DOMAINS = ['1702digital.com', 'theampmworld.com', 'ampmnetwork.com'];
const WHITELIST_EMAILS = ['kuldipmankarr@gmail.com', 'darshit@ampmnetwork.com'];

export async function middleware(request: NextRequest) {
  let response = NextResponse.next();

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => request.cookies.getAll(),
        setAll: (cookies) => {
          cookies.forEach(({ name, value, options }) => {
            request.cookies.set(name, value);
            response.cookies.set(name, value, options);
          });
        },
      },
    }
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const path = request.nextUrl.pathname;
  const isPublic =
    path.startsWith('/login') ||
    path.startsWith('/demo') ||
    path.startsWith('/api/auth') ||
    path.startsWith('/_next') ||
    path === '/manifest.json' ||
    path === '/favicon.ico' ||
    path.startsWith('/icon-');

  // Domain restriction — only @1702digital.com or whitelisted emails
  if (user && user.email) {
    const domain = user.email.split('@')[1];
    const allowed = ALLOWED_DOMAINS.includes(domain) || WHITELIST_EMAILS.includes(user.email);
    if (!allowed && path !== '/login') {
      await supabase.auth.signOut();
      return NextResponse.redirect(new URL('/login?error=domain', request.url));
    }
  }

  if (!user && !isPublic) {
    return NextResponse.redirect(new URL('/login', request.url));
  }
  if (user && path === '/login') {
    return NextResponse.redirect(new URL('/dashboard', request.url));
  }

  return response;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
